﻿#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //定时器,不断获取摄像头数据并发送
     timer = new QTimer(this);
     connect(timer, SIGNAL(timeout()), this, SLOT(show_camera()));
    //定时器2，用于不断发送RFID请求，实现自动刷卡
     timer2 = new QTimer(this);
     connect(timer2, SIGNAL(timeout()), this, SLOT(send_please()));
     //udp 我是发送端
     udpSocket = new QUdpSocket(this);
     udpSocket->bind(QHostAddress::Any, 8888);
     //关联udp可读信号
     connect(udpSocket, SIGNAL(readyRead()), this, SLOT(read_udp_data()));

     //tcp客户端
     tcp_fd = new QTcpSocket(this);
     //关联 连接成功信号
     connect(tcp_fd,SIGNAL(connected()),this,SLOT(con_ok()));
     //定义一个 服务器的IP地址
     QHostAddress   IP("192.168.95.2");
     unsigned short port  = 7777;
     tcp_fd->connectToHost(IP,port);
     // 捕捉 断开连接信号，当网络通信断开时，提示连接已经断开了。
     connect(tcp_fd,SIGNAL(disconnected()),this,SLOT(con_fail()));

    //初始化摄像头设备
    linux_v4l2_yuyv_init("/dev/video7");
    //开启摄像头的捕捉画面功能
    linux_v4l2_start_yuyv_capturing();

      //设置需要初始化的串口
      my_port  = new QSerialPort("/dev/ttySAC1");
      //打开串口设备
      my_port->open(QIODevice::ReadWrite);
      //设置串口的属性
      my_port->setBaudRate(QSerialPort::Baud9600);   //设置波特率为 9600
      my_port->setDataBits(QSerialPort::Data8);     //设置数据位  8 位
      my_port->setStopBits(QSerialPort::OneStop);   //设置停止位 为 1
      my_port->setParity(QSerialPort::NoParity);    //无奇偶校验位
      my_port->setFlowControl(QSerialPort::NoFlowControl); //无数据流控制
      //关联可读信号
      connect(my_port,SIGNAL(readyRead()),this,SLOT(read_port_data()));

      //开启定时器2
      timer2->start(500);
      //开启定时器1 开启视频
      timer->start(1);
      ui->label_5->setText(QString::number(100));

}

MainWindow::~MainWindow()
{
    delete [] timer;
    delete [] timer2;
    delete [] udpSocket;
    delete [] tcp_fd;
    delete [] my_port;
    delete ui;
}
//udp数据，用来更新车位数量
void MainWindow::read_udp_data()
{
    QHostAddress addr;//ip
    quint16 port;//端口号
    while (udpSocket->hasPendingDatagrams())
    {
        //获取udp数据
        QByteArray data;
        data.resize(udpSocket->pendingDatagramSize());
        udpSocket->readDatagram(data.data(), data.size(), &addr, &port);
        //分割地址
        QString addr_msg = addr.toString();
        addr_msg.remove(0, addr_msg.lastIndexOf(":")+1);
        //qDebug() << addr_msg << endl;
        //车位数量
        if(addr_msg == "192.168.95.2")
        {
            QString car_num;
            car_num = data.data();
            ui->label_5->setText(car_num);
        }
        //出库的卡号从卡号列表中删除
        else if(addr_msg == "192.168.94.3")
        {
            for(int i=0; i<card_list.size(); i++)
            {
                if(card_list.at(i).toUtf8() == data)
                {
                    card_list.removeAt(i);

                }
            }
        }
    }
}
//用于不断发送RFID请求，实现自动刷卡
void MainWindow::send_please()
{
    char buf[7]={0};
    buf[0] = 0x07;
    buf[1] = 0x02;
    buf[2] = 0x41;
    buf[3] = 0x01;
    buf[4] = 0x52;

    //配置校验和
    char BCC = 0;
    int i=0;
    for(i=0; i<(buf[0]-2); i++) {
    BCC ^= buf[i];
    }

    buf[5] = ~BCC;
    buf[6] = 0x03;
    my_port->write(buf,7);
}
//连接失败提示
void MainWindow::con_ok()
{
    qDebug() << "connect yes" << endl;
}
//连接成功提示
void MainWindow::con_fail()
{
    qDebug() << "connect no" << endl;
}
//处理串口数据
void MainWindow::read_port_data()
{
    //读取模块所有数据
    char buf[10]={0};
    long long size = my_port->read(buf,10);
     //发送防碰撞获取卡号
    if(size == 8)
    {     
        char cmd[8]={0};
        cmd[0] = 0x08;
        cmd[1] = 0x02;
        cmd[2] = 0x42;
        cmd[3] = 0x02;
        cmd[4] = 0x93;
        cmd[5] = 0x00;
        //配置校验和
        char BCC = 0;
        int i=0;
        for(i=0; i<(cmd[0]-2); i++) {
        BCC ^= cmd[i];
        }
        cmd[6] = ~BCC;
        cmd[7] = 0x03;
        //发送防碰撞获取卡号
        my_port->write(cmd,8);

    }
    else if (size == 10) //防碰撞返回的值
    {
        //如果收到应答，暂停定时器2
        timer2->stop();
        qDebug() << "stop" << endl;
        unsigned int  car_id = buf[7] << 24 | buf[6] << 16 | buf[5] << 8 |  buf[4] ;
        card = QString::number(car_id);
        //如果你的卡号没有出停车场，你不能再次刷卡
        for(int i=0; i<card_list.size(); i++)
        {
            if(card_list.at(i) == card)
            {
                qDebug() <<  "Please first outbound"<< endl;
                timer2->start(500);
                qDebug() << "start" << endl;
                return;
            }

        }
        //上传图片给服务器
        udpSocket->writeDatagram((const char *)jpg_buf.jpg_data, jpg_buf.jpg_size, QHostAddress("192.168.95.2"), 8888);
        //上传车牌，进入时间，卡号数据给服务器 数据格式应统一为carid=xxx|card=xxx|entertime=xxx
        QString msg = QString("card=%1|entertime=%2").arg(card).arg(now_time);
        tcp_fd->write(msg.toUtf8());
        //显示卡号
        ui->label_2->setText(card);

        //发送进入车库的卡号给入口
        udpSocket->writeDatagram(card.toUtf8(), card.size(), QHostAddress("192.168.94.3"), 8888);
        //加入卡号到卡号列表
        card_list.append(card);
        card.clear();
        //处理完数据，开启定时器2
        timer2->start(500);
        qDebug() << "start" << endl;
    }
}
//显示视频流,每毫秒显示
void MainWindow::show_camera()
{
    //实时时间
    QDateTime time = QDateTime::currentDateTime();//获取系统当前时间
    now_time = time.toString("hh:mm:ss");
    //显示当前时间
    ui->label_3->setText(now_time);
    struct jpg_data jpg_buf;

    bzero(&jpg_buf,sizeof(jpg_buf));
    //获取一帧的数据
    linux_v4l2_get_yuyv_data(&jpg_buf);

    QPixmap pic;
    pic.loadFromData(jpg_buf.jpg_data, jpg_buf.jpg_size);
    //适应标签的大小
    pic.scaled(ui->label->width(), ui->label->height());

    ui->label->setPixmap(pic);
    udpSocket->writeDatagram((const char *)jpg_buf.jpg_data, jpg_buf.jpg_size, QHostAddress("192.168.95.2"), 8888);
}


