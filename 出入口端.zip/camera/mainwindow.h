﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QPixmap>
#include <QTimer>
#include <QUdpSocket>
#include <QTcpSocket>
#include <QMessageBox>
#include <QHostAddress>
#include <QTime>
#include <QMessageBox>
//添加 串口 头文件
#include <QSerialPort>
extern "C"
{
    #include "yuyv.h"
}

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:
    void show_camera();
    //连接成功提示
    void con_ok();
    //连接断开提示
    void con_fail();
    //处理串口数据
    void read_port_data();
    //udp数据，用来更新车位数量
    void read_udp_data();
    //不断发送RFID请求，实现自动刷卡
    void send_please();
private:
    Ui::MainWindow *ui;
    //定时器
    QTimer *timer;
    QTimer *timer2;
    //udp socket
    QUdpSocket *udpSocket;
    //处理摄像头数据
    struct jpg_data jpg_buf;
    //tcp socket
    QTcpSocket *tcp_fd;
    //串口
    QSerialPort *my_port;
    //RFID卡号
    QString card;
    //当前时间
    QString now_time;
    //卡号列表
    QStringList card_list = {nullptr};
};
#endif // MAINWINDOW_H
