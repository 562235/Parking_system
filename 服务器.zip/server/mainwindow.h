﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QListWidgetItem>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QUdpSocket>
#include <QTcpServer>
#include <QTcpSocket>
#include <QNetworkDatagram>
#include <QPixmap>
#include <QByteArray>
#include <QFile>
#include "super.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
public slots:
    //当udp有可读信号时，触发本槽函数
    void read_udp_data();
    //当有新的TCP连接请求是，触发本槽函数
    void new_client();
    //当入口端有数据时，触发该槽函数
    void enter_tcp_data();
    //当出口端有数据时，触发该槽函数
    void goto_tcp_data();
    //保存像素数据,生成进入的车牌图片
    void show_enter_pic();
    //保存像素数据,生成出去的车牌图片
    void show_goto_pic();
    //将车牌写到bnf文件中
    void carid_write_bnf(QString &carid);
    friend void *func(void *msg);
private slots:
    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;
    QSqlDatabase db;
    //udp的socket
    QUdpSocket *udp_fd;
    //tcp的socket
    QTcpServer *tcp_server;
    //客户端的tcp socket和标志位
    QTcpSocket *new_clien[2] = {nullptr};
    int i = 0;
    //车位
    int car_num = 100;
    //udp传来的数据
    QByteArray data1;
    QByteArray data2;
    //图片名
    int name = 1;
    int name2 = 1;
    //车牌名
    QString carid_ent;
    QString carid_goto;
    //消费
    int money = 0;
};
#endif // MAINWINDOW_H
