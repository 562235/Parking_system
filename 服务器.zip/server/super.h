﻿#ifndef SUPER_H
#define SUPER_H

#include <QMainWindow>
#include <QListWidgetItem>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QFileDialog>
#include <QSqlQuery>
#include <QDebug>
#include <unistd.h>

namespace Ui {
class super;
}

class super : public QMainWindow
{
    Q_OBJECT

public:
    explicit super(QWidget *parent = nullptr);
    ~super();

    //显示数据
    void show_data();
private slots:

    void on_listWidget_itemDoubleClicked(QListWidgetItem *item);


    void on_tableWidget_cellDoubleClicked(int row, int column);

    void on_pushButton_3_clicked();


    void on_back_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::super *ui;
    QSqlDatabase db;
    //有多少列
    int col;

    //设置表头
    QStringList  head;


    //选中的坐标
    int x;
    int y;

    //当前操作的表名字
    QString table_name;

    //多少行
    int j=0;

};

#endif // SUPER_H
