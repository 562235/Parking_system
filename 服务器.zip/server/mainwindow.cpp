﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>
#include <QJsonParseError>
#include "iostream"
#include "ocr.h"
#include "pthread.h"
#include <unistd.h>

int a = 0;
//用于语音播报的线程
void *func(void *msg)
{
    while(1)
    {
        if(a == 1)
        {
            MainWindow *win = (MainWindow *)msg;
            QString talk = win->carid_ent;
            //如果字符串中有空格 除去它
            if((talk.indexOf(" ") >= 0))
            {
                QStringList flag = talk.split(" ");
                talk = flag.at(1);
            }
            qDebug()  << "talk：" << talk << endl;
            QString data = QString("./tts_offline_sample 欢迎光临%1车主").arg(talk);

            //语音播报
            chdir("./text_to_talk/bin/");
            system(data.toUtf8());
            system("aplay 1.wav");
            chdir("/home/lizhengwen/share/qt-projects/server");
            a = 0;
        }
        else if(a == 2)
        {
            MainWindow *win = (MainWindow *)msg;
            QString talk = win->carid_goto;
            //如果字符串中有空格 除去它
            if((talk.indexOf(" ") >= 0))
            {
                QStringList flag = talk.split(" ");
                talk = flag.at(1);
            }
            qDebug()  << "talk：" << talk << endl;
            QString data = QString("./tts_offline_sample %1车主您本次消费%2元，期待您的再次光临").arg(talk).arg(win->money);

            //语音播报
            chdir("./text_to_talk/bin/");
            system(data.toUtf8());
            system("aplay 1.wav");
            chdir("/home/lizhengwen/share/qt-projects/server");
            a = 0;
        }
    }

}

//服务器端
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //1.设置数据库的类型
    db  = QSqlDatabase::addDatabase("QSQLITE");
    //设置路径  CREATE TABLE car(carid text, entertime text, gotime text, level text,card text);
    db.setDatabaseName("/home/lizhengwen/share/sql/mypark.db");
    //2.打开数据库,用于存放车辆信息
    if(db.open())
        qDebug() << "打开数据库成功"  << endl;
    else
       qDebug() << "打开数据库失败"  << endl;

    //打开udp用于接收视频
    udp_fd = new QUdpSocket(this);
    //绑定本地地址
    udp_fd->bind(QHostAddress::Any, 8888);
    //关联udp可读信号
    connect(udp_fd, SIGNAL(readyRead()), this, SLOT(read_udp_data()));

    //打开tcp，用于接收卡号，时间等信息
    tcp_server = new QTcpServer(this);
    //设置服务器为监听模式
   if(tcp_server->listen(QHostAddress("192.168.95.2"),7777))
   {
            qDebug() << "设置监听模式成功"  << endl;
   }
   else
   {
          qDebug() << "设置监听模式失败"  << endl;
   }
   //关联tcp连接请求信号
   connect(tcp_server,SIGNAL(newConnection()),this,SLOT(new_client()));
   //用于语音播报的线程
   pthread_t pid;
   pthread_create(&pid, nullptr, func, (void *)this);

}
//回收资源
MainWindow::~MainWindow()
{
    system("rm ./*.jpg");
    delete [] udp_fd;
    delete [] tcp_server;
    delete [] new_clien[0];
    delete [] new_clien[1];
    delete ui;
}

//当udp有图片传过来时，触发本槽函数,将图片显示在屏幕上
void MainWindow::read_udp_data()
{
    QHostAddress addr;//ip
    quint16 port;//端口号
    while (udp_fd->hasPendingDatagrams())
    {
        //获取udp数据
        QByteArray data;
        data.resize(udp_fd->pendingDatagramSize());
        udp_fd->readDatagram(data.data(), data.size(), &addr, &port);

        QPixmap pic;
        pic.loadFromData(data);
        //分割地址
        QString addr_msg = addr.toString();
        addr_msg.remove(0, addr_msg.lastIndexOf(":")+1);
        if(addr_msg == "192.168.95.3")
        {
            data1 = data;
            pic.scaled(ui->label->width(), ui->label->height());
            ui->label->setPixmap(pic);
        }
        //不然的话显示在出口
        else
        {
            data2 = data;
            pic.scaled(ui->label_2->width(), ui->label_2->height());
            ui->label_2->setPixmap(pic);
        }
    }
}
//将车牌写到bnf文件中
void MainWindow::carid_write_bnf(QString &carid)
{
    //打开/home/lizhengwen/share/kdxf/talk_to_text/bin/mycall.bnf
    QFile bnf_file("/home/lizhengwen/share/kdxf/talk_to_text/bin/mycall.bnf");
    bnf_file.open(QIODevice::ReadWrite|QIODevice::Text);
    QString bnf_txt = bnf_file.readAll();
    //分析文件内容,将最后的id+1 和车牌名加入进去
    if(bnf_txt.indexOf(carid) < 0)
    {
        QString num = bnf_txt.at(bnf_txt.lastIndexOf("id")+3);
        num = QString::number(num.toInt() + 1);
        num = QString("|%1!id(%2);").arg(carid).arg(num);
        //如果成功定位到文件末尾-1,则添加内容
        if(bnf_file.seek(bnf_file.size()-1) == true)
        {
            bnf_file.write(num.toUtf8());
        }
    }

    bnf_file.close();
   // qDebug() << num << endl;
}
//保存车牌，生成进入的车牌图片
void MainWindow::show_enter_pic()
{
    //图片生成的路径
    QString pic_path = QString("./入库%1.jpg").arg(name++);
    QFile carid_pic(pic_path);
    //文件可读写且，如果不存在则创建，存在则失败
    carid_pic.open(QIODevice::ReadWrite | QIODevice::NewOnly);
    carid_pic.write(data1);
   //提交图片给百度api 处理
   // 设置APPID/AK/SK
   std::string app_id = "18168648";
   std::string api_key = "akwdEZH17wavAHe1Ml8IlTPa";
   std::string secret_key = "uuj2jKLRLG1a0CAT9FxrRXaABKzKnw4C";
   aip::Ocr client(app_id, api_key, secret_key);
   //初始化需要识别的图像
   Json::Value result;
   std::string image;
   aip::get_file_content(pic_path.toUtf8().data(), &image);
   // 调用通用文字识别（高精度版）
   result = client.accurate_basic(image, aip::null);
   QString  msg = result.toStyledString().data();
   QJsonParseError err;
   QJsonDocument    json=  QJsonDocument::fromJson(msg.toUtf8(),&err);
   if(err.error != QJsonParseError::NoError)
   {
      qDebug() << "错误" << endl;
   }
   QJsonObject obj    = json.object();
   QJsonArray  arry   = obj.take("words_result").toArray();
   for (int i=0;i<arry.size();i++)
   {
       carid_ent  = arry.at(i).toObject().take("words").toString();
   }
   //把图片名设置为车牌名
   pic_path = QString("./%1.jpg").arg(carid_ent);
   if(carid_pic.rename(pic_path) == false)
   {
       qDebug() << "rename fail" << endl;
   }
   carid_write_bnf(carid_ent);
   qDebug() << carid_ent << endl;
   a = 1;

}

//保存车牌，生成出去的车牌图片
void MainWindow::show_goto_pic()
{
    //图片生成的路径
    QString pic_path = QString("./出库%1.jpg").arg(name2++);
    QFile carid_pic(pic_path);
    //文件可读写且，如果不存在则创建，存在则失败
    carid_pic.open(QIODevice::ReadWrite | QIODevice::NewOnly);
    carid_pic.write(data2);
    //显示车牌
    /*QPixmap pix(pic_path);
    pix = pix.scaled(ui->chepai1->width(), ui->chepai1->height());
    ui->chepai1->setPixmap(pix);*/

   //提交图片给百度api 处理
   // 设置APPID/AK/SK
   std::string app_id = "18168648";
   std::string api_key = "akwdEZH17wavAHe1Ml8IlTPa";
   std::string secret_key = "uuj2jKLRLG1a0CAT9FxrRXaABKzKnw4C";
   aip::Ocr client(app_id, api_key, secret_key);
   //初始化需要识别的图像
   Json::Value result;
   std::string image;
   aip::get_file_content(pic_path.toUtf8().data(), &image);
   // 调用通用文字识别（高精度版）
   result = client.accurate_basic(image, aip::null);
   QString  msg = result.toStyledString().data();
   QJsonParseError err;
   QJsonDocument    json=  QJsonDocument::fromJson(msg.toUtf8(),&err);
   if(err.error != QJsonParseError::NoError)
   {
      qDebug() << "错误" << endl;
   }
   QJsonObject obj    = json.object();
   QJsonArray  arry   = obj.take("words_result").toArray();
   for (int i=0;i<arry.size();i++)
   {
       carid_goto  = arry.at(i).toObject().take("words").toString();
   }
   //把图片名设置为车牌名
   pic_path = QString("./%1.jpg").arg(carid_goto);
   if(carid_pic.rename(pic_path) == false)
   {
       qDebug() << "rename fail" << endl;
   }
   carid_write_bnf(carid_goto);
   qDebug() << carid_goto << endl;

}

//当有新的TCP连接请求是，触发本槽函数。先进来的是入口
void MainWindow::new_client()
{
    //产生新的通信对象
    new_clien[i]   = tcp_server->nextPendingConnection();
    if(i == 0)
    {
        //关联入口端的可读信号
        connect(new_clien[0],SIGNAL(readyRead()),this,SLOT(enter_tcp_data()));
    }
    else if(i == 1)
    {
        //关联出口端的可读信号
        connect(new_clien[1],SIGNAL(readyRead()),this,SLOT(goto_tcp_data()));
    }

    //打印连接者的IP 地址信息
    QString  IP   = new_clien[i++]->peerAddress().toString();
    qDebug() << "tcp：" << IP << endl;

}
//入口端的数据处理函数,将车牌，卡号，进入时间写入到数据库中
void MainWindow::enter_tcp_data()
{
    //有车辆进入，车位减一
    car_num--;
    QString car_num_str = QString::number(car_num);
    //显示车牌
    show_enter_pic();
    //数据格式应统一为carid=xxx|card=xxx|entertime=xxx
    QString msg = new_clien[0]->readAll();
    //以 | 为分割符
    QStringList msg_list = msg.split("|");
    QSqlQuery  sql_cmd;
    //分割卡号，进入时间
    QString card = msg_list[0];
    card.remove(0, card.lastIndexOf("=")+1);
    //进入时间
    QString entertime = msg_list[1];
    entertime.remove(0, entertime.lastIndexOf("=")+1);
    //查询表中有没有该卡号，有则更新，没有则增加
    QString cmd = QString("select * from car where card like '%1';").arg(card);
    if(sql_cmd.exec(cmd))
    {
        qDebug() << "查找成功" << endl;
        int j = 0;
        while(sql_cmd.next())
            j++;
        //如果没有则增加,车牌，卡号，级别，进入时间
        if(j <= 0)
        {
            cmd = QString("insert into car(carid, card, level, entertime) values('%1', '%2', '%3', '%4')").arg(carid_ent).arg(card).arg("普通用户").arg(entertime);
            if(sql_cmd.exec(cmd))
            {
                //更新车位
                udp_fd->writeDatagram(car_num_str.toUtf8(), sizeof (car_num_str), QHostAddress("192.168.94.3"), 8888);
                udp_fd->writeDatagram(car_num_str.toUtf8(), sizeof (car_num_str), QHostAddress("192.168.95.3"), 8888);
                qDebug() << "增加成功" << endl;
            }
            else
                qDebug() << "增加失败" << endl;
        }
        //如果有,则更新车牌，进入时间
        else
        {
            cmd = QString("update car set carid = '%1', entertime = '%2' where card = '%3';").arg(carid_ent).arg(entertime).arg(card);
            if(sql_cmd.exec(cmd))
            {
                //更新车位
                udp_fd->writeDatagram(car_num_str.toUtf8(), sizeof (car_num_str), QHostAddress("192.168.94.3"), 8888);
                udp_fd->writeDatagram(car_num_str.toUtf8(), sizeof (car_num_str), QHostAddress("192.168.95.3"), 8888);
                qDebug() << "更新成功" << endl;
            }
            else
                qDebug() << "更新失败" << endl;
        }
    }

}
//出口端的数据处理函数,将卡号，出去时间写入到数据库中
void MainWindow::goto_tcp_data()
{
    //有车辆出去，车位加一
    car_num++;
    QString car_num_str = QString::number(car_num);
    //显示车牌
    show_goto_pic();
    //数据格式应统一为card=xxx|time=xxx
    QString msg = new_clien[1]->readAll();
    //以 | 为分割符
    QStringList msg_list = msg.split("|");
    QSqlQuery  sql_cmd;

    //分割车牌，卡号，进入时间
    QString card = msg_list[0];
    card.remove(0, card.lastIndexOf("=")+1);
    QString gotime = msg_list[1];
    gotime.remove(0, gotime.lastIndexOf("=")+1);

    //查询表中有没有该卡号，有则更新，没有则报警
    QString cmd = QString("select * from car where card like '%1';").arg(card);
    if(sql_cmd.exec(cmd))
    {
        qDebug() << "查找成功" << endl;
        int j = 0;
        while(sql_cmd.next())
            j++;
        //如果没有则报警
        if(j <= 0)
        {
            QMessageBox::warning(this, "提示", "您的卡号不存在，请重试", QMessageBox::Ok);
        }
        //如果有则更新出去时间,并提示消费多少
        else
        {
            cmd = QString("update car set gotime = '%1' where card = '%2';").arg(gotime).arg(card);
            //更新车位
            udp_fd->writeDatagram(car_num_str.toUtf8(), sizeof (car_num_str), QHostAddress("192.168.94.3"), 8888);
            udp_fd->writeDatagram(car_num_str.toUtf8(), sizeof (car_num_str), QHostAddress("192.168.95.3"), 8888);
            if(sql_cmd.exec(cmd))
            {
                qDebug() << "更新成功" << endl;
                //计算消费 公式为(gotime - entertime) * 3 普通3块，月卡2块，年卡1块
                cmd = QString("select * from car;");
                //计算消费 选择表里所有的数据
                if(sql_cmd.exec(cmd))
                {
                    while(sql_cmd.next())
                    {
                        //如果找到了对应的卡号,则计算消费
                        if(sql_cmd.value(4).toString() == card)
                        {
                            //获取进入时间
                            QString date = sql_cmd.value(1).toString();
                            QStringList entime_list =  date.remove(5, 7).split(":");
                            QString entime = QString::number( (entime_list.at(0).toInt()*60 + entime_list.at(1).toInt()));
                            //qDebug() << "entime" << entime << endl;
                            //获取出去时间
                            QStringList gotime_list =  gotime.remove(5, 7).split(":");
                            gotime = QString::number( (gotime_list.at(0).toInt()*60 + gotime_list.at(1).toInt()));
                            //qDebug() << "gotime" << gotime << endl;
                            //算好消费后 播放语音
                            money = abs((gotime.toInt() - entime.toInt())*3);
                            a = 2;
                            //如果是普通用户(gotime - entertime) * 3
                            if(sql_cmd.value(3).toString() == "普通用户")
                            {
                                qDebug() << "亲爱的用户，您的费用为:" << money*3 << endl;
                            }
                            else if(sql_cmd.value(3).toString() == "月卡用户" )
                            {
                                qDebug() << "尊敬的月卡用户，您的费用为:" << money*2 << endl;
                            }
                            else if(sql_cmd.value(3).toString() == "年卡用户")
                            {
                                qDebug() << "尊贵的年卡用户，您的费用为:" << money*1 << endl;
                            }
                        }
                    }
                }
            }
            else
                qDebug() << "更新失败" << endl;

        }
    }
}

//进入管理员界面
void MainWindow::on_pushButton_2_clicked()
{
    super *win = new super(this);
    win->show();
    this->hide();
}
