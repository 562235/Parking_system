/********************************************************************************
** Form generated from reading UI file 'super.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUPER_H
#define UI_SUPER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_super
{
public:
    QWidget *centralwidget;
    QListWidget *listWidget;
    QPushButton *pushButton_3;
    QPushButton *back;
    QLabel *label;
    QLineEdit *lineEdit;
    QTableWidget *tableWidget;
    QPushButton *pushButton_4;
    QLabel *label_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *super)
    {
        if (super->objectName().isEmpty())
            super->setObjectName(QString::fromUtf8("super"));
        super->resize(1000, 700);
        centralwidget = new QWidget(super);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(885, 0, 111, 561));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(360, 490, 101, 71));
        back = new QPushButton(centralwidget);
        back->setObjectName(QString::fromUtf8("back"));
        back->setGeometry(QRect(760, 490, 111, 71));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(740, 430, 141, 41));
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(360, 420, 351, 41));
        tableWidget = new QTableWidget(centralwidget);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(360, 0, 521, 401));
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(570, 490, 101, 71));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(0, 0, 351, 561));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        super->setCentralWidget(centralwidget);
        menubar = new QMenuBar(super);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1000, 28));
        super->setMenuBar(menubar);
        statusbar = new QStatusBar(super);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        super->setStatusBar(statusbar);

        retranslateUi(super);

        QMetaObject::connectSlotsByName(super);
    } // setupUi

    void retranslateUi(QMainWindow *super)
    {
        super->setWindowTitle(QCoreApplication::translate("super", "MainWindow", nullptr));
        pushButton_3->setText(QCoreApplication::translate("super", "\346\233\264\346\226\260", nullptr));
        back->setText(QCoreApplication::translate("super", "\350\277\224\345\233\236", nullptr));
        label->setText(QCoreApplication::translate("super", "TextLabel", nullptr));
        lineEdit->setPlaceholderText(QCoreApplication::translate("super", "\350\257\267\350\276\223\345\205\245\351\234\200\350\246\201\344\277\256\346\224\271\347\232\204\346\225\260\346\215\256", nullptr));
        pushButton_4->setText(QCoreApplication::translate("super", "\350\257\255\351\237\263\346\237\245\350\257\242", nullptr));
        label_2->setText(QCoreApplication::translate("super", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class super: public Ui_super {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUPER_H
