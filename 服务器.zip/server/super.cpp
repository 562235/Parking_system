﻿#include "super.h"
#include "ui_super.h"


super::super(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::super)
{
    ui->setupUi(this);
    //1.设置数据库的类型
    db  = QSqlDatabase::addDatabase("QSQLITE");
    //设置路径
    db.setDatabaseName("/home/lizhengwen/share/sql/mypark.db");
    //2.打开数据库
    if(db.open())
    {
            QMessageBox::warning(this, tr("温馨提示"),tr("打开数据库成功"),QMessageBox::Ok);
            //获取表格
            QStringList table_list  = db.tables();

            ui->listWidget->clear();
            ui->listWidget->addItems(table_list);

    }
    else
        QMessageBox::warning(this, tr("温馨提示"),tr("打开数据库失败"),QMessageBox::Ok);
}

super::~super()
{
    delete ui;
}

//双击表名后显示表中的数据
void super::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
    j = 0;
    col = 0;
    head.clear();
    //获取表格信息设置表格
    QSqlQuery  sql_cmd;
    QString cmd;
    // pragma table_info(表名)；
    table_name = item->text();
    cmd = QString("pragma table_info(%1);").arg(item->text());
    if(sql_cmd.exec(cmd))
    {
         //获取表格的字段数
        while(sql_cmd.next())
        {
            col++;
            head<< sql_cmd.value(1).toString();
        }
    }
    else {
        QMessageBox::warning(this, tr("温馨提示"),tr("执行命令失败"),QMessageBox::Ok);
    }
    //设置数据库的表头
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(col);
    ui->tableWidget->setHorizontalHeaderLabels(head);
    //查询数据库中的数据
    cmd = QString("select * from %1;").arg(item->text());
    if(sql_cmd.exec(cmd))
    {
        //获取表格的字段数
        while(sql_cmd.next())
        {
            //插入一行数据
            ui->tableWidget->insertRow(j);

            //设置数据
            for(int i=0;i<col;i++)
            {
            QString data  = sql_cmd.value(i).toString();

            //设置到表格中
            QTableWidgetItem *it  = new QTableWidgetItem(data);
            ui->tableWidget->setItem(j,i,it);
        }

        j++;
    }
    }
    else
        QMessageBox::warning(this, tr("温馨提示"),tr("执行命令失败"),QMessageBox::Ok);

}

//双击表格中的一个数据 取出来
void super::on_tableWidget_cellDoubleClicked(int row, int column)
{

       //取行与列
        qDebug() << row << endl;
        qDebug() << column+1 << endl;
         x = row; //行
         y = column;//列

         //取出原来的数据
         QTableWidgetItem  *it   = ui->tableWidget->takeItem(row,column);
         if(it == nullptr)
        {
            qDebug()  << " IS  nullptr" << endl;
            return ;
        }
         ui->label->setText(it->text());
}

//更新
void super::on_pushButton_3_clicked()
{
    QSqlQuery  sql_cmd;
    QString cmd;
    QString  s =  head.at(y);
    QString  carid = head.at(4);
    QString  car = ui->tableWidget->takeItem(x, 4)->text();
     //update  表名   set id=    where  id=

    cmd = QString("update %1 set %2='%3' where %4='%5';").arg(table_name).arg(s).arg(ui->lineEdit->text()).arg(carid).arg(car);
    qDebug() << cmd << endl;
    //命令如何设计
    if(sql_cmd.exec(cmd))
    {
        qDebug() << " 执行语句成功"  << endl;
    }
    else {
        qDebug() << " 执行语句失败"  << endl;
    }
}

//返回上层
void super::on_back_clicked()
{
    this->parentWidget()->show();
    this->close();
}
//语音查询
void super::on_pushButton_4_clicked()
{
    //录制音频文件
    qDebug() << "请开始说话\n" << endl;
    system("arecord -d4 -c1 -r16000 -traw -fS16_LE mycall.pcm");
    system("cp mycall.pcm /home/lizhengwen/share/kdxf/talk_to_text/bin/wav/");
    //system("rm mycall.pcm");
    //语音转文字
    chdir("/home/lizhengwen/share/kdxf/talk_to_text/bin");
    system("./asr_offline_sample");
    chdir("/home/lizhengwen/share/qt-projects/server");
    //获取并解析文字
    QFile file("/home/lizhengwen/share/kdxf/talk_to_text/bin/chepai.txt");
    file.open(QIODevice::ReadWrite|QIODevice::Text);
    QString chepai = file.readAll();
    chepai.remove(0, chepai.indexOf("id=")+7).remove(chepai.indexOf("</carid"), chepai.size()-1);
    //显示对应图片
    QString pic_name = QString("./%1.jpg").arg(chepai);
    QPixmap pic(pic_name);
    pic = pic.scaled(ui->label_2->width(), ui->label_2->height());
    ui->label_2->setPixmap(pic);
}





